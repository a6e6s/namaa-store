for installation 

change the config file details 

change the path of your root in (public/.htaccess) and (admin/.htaccess)
