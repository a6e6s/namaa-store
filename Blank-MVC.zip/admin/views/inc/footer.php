
<!-- footer content -->
<footer>
    <div class="pull-right">
        Easy CMS by: <a class="text-primary" href="https://ahmedx.com">Ahmed Elmahdy</a>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->
</div>
</div>
<!-- jQuery -->
<script src="<?php echo ADMINURL; ?>/template/default/vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo ADMINURL; ?>/template/default/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo ADMINURL; ?>/template/default/vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="<?php echo ADMINURL; ?>/template/default/vendors/nprogress/nprogress.js"></script>
<!-- iCheck -->
<script src="<?php echo ADMINURL; ?>/template/default/vendors/iCheck/icheck.min.js"></script>
<!-- colorpicker -->
<script src="<?php echo ADMINURL; ?>/template/default/vendors/colorpicker/js/wheelcolorpicker.min.js"></script>
<!-- jQuery Smart Wizard -->
<script src="<?php echo ADMINURL; ?>/template/default/vendors/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
<?php echo $data['footer']; ?>
<!-- Custom Theme Scripts -->
<script src="<?php echo ADMINURL; ?>/template/default/js/custom.min.js"></script>
</body>
</html>
